import CONFIG from '../../globals/config';

const createRestaurantDetailTemplate = (restaurant) => `
<div class="img-detail-container">
  <img class="restaurant__poster" src="${CONFIG.BASE_IMAGE_URL + restaurant.pictureId}" alt="${restaurant.title}">
  <div class="restaurant__info">
    <h1>${restaurant.name}</h1>
    <h4>Alamat</h4>
    <p>${restaurant.address}, ${restaurant.city} </p>
    <h4>Rating ⭐️ ${restaurant.rating}</h4>
  </div>
  <div class="restaurant__overview">
    <h3>Deskripsi</h3>
    <p>${restaurant.description}</p>
  </div>
</div>
    <h2 class="menu-title">Menu</h3>
    <div id="menu-box" class="detail-menu grid-2">
      <div  class="detail-food">
        <h4>Food</h4>
        <ul>
          ${restaurant.menus.foods
    .map(
      (food) => `
                <li>${food.name}</li>
              `,
    )
    .join('')}
        </ul>
      </div>
      <div class="detail-drink">
        <h4>Drink</h4>
        <ul>
          ${restaurant.menus.drinks
    .map(
      (drink) => `
                <li>${drink.name}</li>
              `,
    )
    .join('')}
        </ul>
      </div>
    </div>
  </div>
  <div class="restaurant__overview">
    <h3>Reviews</h3>
    <div id="review-box" class="detail-review grid-3">
    ${restaurant.customerReviews
    .map(
      (review) => `
          <div class="detail-review-item">
            <div class="review-header">
              <p class="review-name"><i title="restaurant" class="fa fa-user-circle" style="font-size:1.3em;"></i>&nbsp;${review.name}</p>
              <p class="review-date">${review.date}</p>
            </div>
            <div class="review-body">
              ${review.review}
            </div>
          </div>
        `,
    )
    .join('')}
    </div>
  </div>
`;
const createRestaurantItemTemplate = (restaurant) => `
  <div class="restaurant-item">
    <div class="restaurant-item__header">
        <img class="restaurant-item__header__poster" alt="${restaurant.name}"
        src="${CONFIG.BASE_IMAGE_URL + restaurant.pictureId}">
        <div class="restaurant-item__header__rating">
            <p>⭐️<span class="restaurant-item__header__rating__score">${restaurant.rating}</span></p>
        </div>
    </div>
    <div class="restaurant-item__content">
        <h3><a href="${`/#/detail/${restaurant.id}`}">${restaurant.name}</a></h3>
        <p>${restaurant.description}</p>
    </div>
  </div>
  `;

const createLikeButtonTemplate = () => `
  <button aria-label="like this restaurant" id="likeButton" class="like">
     <i class="fa fa-heart-o" aria-hidden="true"></i>
  </button>
`;

const createLikedButtonTemplate = () => `
  <button aria-label="unlike this restaurant" id="likeButton" class="like">
    <i class="fa fa-heart" aria-hidden="true"></i>
  </button>
`;

export {
  createRestaurantItemTemplate,
  createRestaurantDetailTemplate,
  createLikeButtonTemplate,
  createLikedButtonTemplate,
};
