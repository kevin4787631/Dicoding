/* eslint-disable no-unused-vars */
/* eslint-disable arrow-parens */
import 'regenerator-runtime';
import '../styles/main.sass';
import '../styles/responsive.sass';
import App from './views/app';
import swRegister from './utils/sw-register';

window.onload = function (e) {
  const app = new App({
    button: document.querySelector('#hamburger'),
    drawer: document.querySelector('#drawer'),
    content: document.querySelector('#posts'),
  });
};

const app = new App({
  button: document.querySelector('#hamburger'),
  drawer: document.querySelector('#drawer'),
  content: document.querySelector('#posts'),
});

window.addEventListener('hashchange', () => {
  app.renderPage();
});

window.addEventListener('load', () => {
  app.renderPage();
  swRegister();
});
